﻿# -*- coding: utf-8 -*-
"""
Created on Sun Jun 16 22:23:24 2019

@author: HP
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Dec  8 07:11:11 2018

@author: HP
"""

from keras import backend as K
from keras import optimizers
from keras.optimizers import Adam
import keras.backend.tensorflow_backend as KTF
import glob
from keras.layers import Input,Dense,Dropout,BatchNormalization,Conv2D,MaxPooling2D,AveragePooling2D,concatenate,Activation,ZeroPadding2D
import tensorflow as tf
import cv2
import numpy as np
import pandas as pd
import keras
from keras.models import load_model
from keras.layers import Activation, Dense
from matplotlib import pyplot as plt
from skimage import io,data
import time
from keras import layers
from keras.callbacks import ModelCheckpoint, TensorBoard
from keras.preprocessing.image import ImageDataGenerator

from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
now = time.strftime("%Y-%m-%d_%H-%M-%S", time.localtime())

import os,sys
os.getcwd()
os.chdir("/home/cjd/25_Entity_shop")

print(os.getcwd())
print (sys.version)


os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "2,3,5"


config = tf.ConfigProto()
#config.gpu_options.per_process_gpu_memory_fraction = 0.6
config.gpu_options.allow_growth = True
keras.backend.tensorflow_backend.set_session(tf.Session(config=config))



import tensorflow as tf        
def focal_loss(gamma=2.):            
    def focal_loss_fixed(y_true, y_pred):
        pt_1 = tf.where(tf.equal(y_true, 1), y_pred, tf.ones_like(y_pred))
        return -K.sum( K.pow(1. - pt_1, gamma) * K.log(pt_1)) 
    return focal_loss_fixed


def Conv2d_BN(x, nb_filter,kernel_size, strides=(1,1), padding='same',name=None):  
    if name is not None:  
        bn_name = name + '_bn'  
        conv_name = name + '_conv'  
    else:  
        bn_name = None  
        conv_name = None  
  
    x = Conv2D(nb_filter,kernel_size,padding=padding,strides=strides,activation='relu',name=conv_name)(x)  
    x = BatchNormalization(axis=3,name=bn_name)(x)  
    return x  

def Conv_Block(inpt,nb_filter,kernel_size,strides=(1,1), with_conv_shortcut=False):  
    x = Conv2d_BN(inpt,nb_filter=nb_filter[0],kernel_size=(1,1),strides=strides,padding='same')  
    x = Conv2d_BN(x, nb_filter=nb_filter[1], kernel_size=(3,3), padding='same')  
    x = Conv2d_BN(x, nb_filter=nb_filter[2], kernel_size=(1,1), padding='same')  
    if with_conv_shortcut:  
        shortcut = Conv2d_BN(inpt,nb_filter=nb_filter[2],strides=strides,kernel_size=kernel_size)  
        x = add([x,shortcut])  
        return x  
    else:  
        x = add([x,inpt])  
        return x  



batch_size = 32 
epochs = 30
MODEL_INIT = './obj_reco/init_model.h5'
MODEL_PATH = './obj_reco/tst_model.h5'
board_name1 = './obj_reco/stage1/' + now + '/'
board_name2 = './obj_reco/stage2/' + now + '/'
train_dir='./train_seg/'
validation_dir='./test_seg/'
img_size = (224, 224)  
#classes=list(range(1,5))
#classes=['1','2','3','4']
nb_train_samples = len(glob.glob(train_dir + '/*/*.*'))  
nb_validation_samples = len(glob.glob(validation_dir + '/*/*.*'))  

classes = sorted([o for o in os.listdir('./train_seg')])  




'''
#---------MobileNetV2 transfer learning--------------------------------------------------------------
import tensorflow as tf
from keras.preprocessing import image
from keras.models import Model
from keras.layers import Dense, GlobalAveragePooling2D
from keras import backend as K
from keras import regularizers


IMG_SHAPE=(224, 224, 3)

base_model = keras.applications.MobileNetV2(input_shape=IMG_SHAPE,include_top=False, 
weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/mobilenet_v2_weights_tf_dim_ordering_tf_kernels_1.0_224_no_top.h5')


for layer in base_model.layers:
    layer.trainable = False
    
x = base_model.output
x = GlobalAveragePooling2D()(x)


#predictions = Dense(len(ont_hot_labels[0]), activation='softmax', kernel_regularizer =regularizers.l2(0.01) )(x)  #l1_reg
predictions = Dense(len(classes), activation='softmax', kernel_regularizer =regularizers.l2(0.01) )(x)  #l1_reg

model = Model(inputs=base_model.input, outputs=predictions)

model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
#model.compile(loss='categorical_crossentropy', optimizer=optimizers.Adadelta(), metrics=['accuracy'])
'''


'''
#----------STN+MobileNetV2 transfer learning---------------------------------------------------------------
#-----------------------------------------------------------------------------------
from keras.layers import Dense, GlobalAveragePooling2D, GlobalMaxPooling2D, Input
from spatial_transformer_network import SpatialTransformer
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation, Flatten
from keras.layers.convolutional import Convolution2D, MaxPooling2D
#MobileNet迁移学习包
import tensorflow as tf
from keras.preprocessing import image
from keras.models import Model
from keras.layers import Dense, GlobalAveragePooling2D
from keras import backend as K
from keras import regularizers
import efficientnet.keras as efn 

b = np.zeros((2, 3), dtype='float32')
b[0, 0] = 1
b[1, 1] = 1
W = np.zeros((50, 6), dtype='float32')
weights = [W, b.flatten()]
#localization net, acquired map coef:theta
input_shape=(224,224,3)

from keras import backend as K  
K.set_image_dim_ordering('tf')  

locnet = Sequential()
locnet.add(MaxPooling2D(pool_size=(2,2), input_shape=input_shape))
locnet.add(Convolution2D(20, 5, 5))
locnet.add(MaxPooling2D(pool_size=(2,2)))
locnet.add(Convolution2D(20, 5, 5))

locnet.add(Flatten())
locnet.add(Dense(50))
locnet.add(Activation('relu'))
locnet.add(Dense(6, weights=weights)) 
#locnet.add(Activation('sigmoid'))


#K.set_learning_phase(0)
IMG_SHAPE=(224, 224, 3)

base_model = efn.EfficientNetB0(input_shape=IMG_SHAPE,include_top=False, 
weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/efficientnet-b0_weights_tf_dim_ordering_tf_kernels_autoaugment_notop.h5')

for layer in base_model.layers:
    layer.trainable = False


#build the model
#K.set_learning_phase(1)
#input_layer = keras.layers.Input(IMG_SHAPE)
input_layer=Input(shape=(224,224,3))
model = Sequential()
#model_input = Input(shape=img_dim)
stn_mdl= SpatialTransformer(localization_net=locnet,
                         output_size=(224,224))(input_layer)

model.add(SpatialTransformer(localization_net=locnet,output_size=(224,224),
                            input_shape=(224,224,3)))


model.add(base_model)
x = model.output
#x = Conv2d_BN(x,nb_filter=2048,kernel_size=(5,5),strides=(1,1),padding='same')
x = GlobalAveragePooling2D()(x)
predictions = Dense(len(classes),  activation='softmax', kernel_regularizer =regularizers.l2(0.01) )(x)  #l1_reg
model = Model(inputs=model.input, outputs=predictions)
model.compile(loss='categorical_crossentropy', optimizer=optimizers.Adadelta(), metrics=['accuracy'])
'''

'''
model.add(base_model)
model.add(layers.GlobalAveragePooling2D())
model.add(layers.Dense(1024, activation="relu"))
model.add(layers.Dropout(0.4))
model.add(layers.Dense(len(classes), activation='softmax'))
model.compile(optimizer='adam', loss='categorical_crossentropy' , metrics = ['accuracy'])  #rmsprop   loss = [focal_loss(gamma=2)],
'''


'''
#---------Efficientnet transfer learning--------------------------------------------------------------
import tensorflow as tf
from keras.preprocessing import image
from keras.models import Model
from keras.layers import Dense, GlobalAveragePooling2D
from keras import backend as K
from keras import regularizers
import efficientnet.keras as efn 

IMG_SHAPE=(224, 224, 3)

base_model = efn.EfficientNetB0(input_shape=IMG_SHAPE,include_top=False, 
weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/efficientnet-b0_weights_tf_dim_ordering_tf_kernels_autoaugment_notop.h5')

for layer in base_model.layers:
    layer.trainable = False

x = base_model.output
x = GlobalAveragePooling2D()(x)

predictions = Dense(len(classes), activation='softmax')(x)
model = Model(inputs=base_model.input, outputs=predictions)
model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
'''



#----------Ensemble learning, two-stage transfer learning, MobileNet EfficieNet ---------------------------------------------------------------
#-----------------------------------------------------------------------------------
from keras.layers import Dense, GlobalAveragePooling2D, GlobalMaxPooling2D, Input, add, Flatten  
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation, Flatten
from keras.layers.convolutional import Convolution2D, MaxPooling2D
from keras.applications.densenet import DenseNet121,preprocess_input
import tensorflow as tf
from keras.preprocessing import image
from keras.models import Model
from keras.layers import Dense, GlobalAveragePooling2D
from keras import backend as K
from keras import regularizers
import efficientnet.keras as efn 


IMG_SHAPE=(224, 224, 3)
input_layer=Input(shape=(224,224,3))
model_input = Input(shape=(224,224,3))
optimizer = Adam(lr=0.0001, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=True)

base_model1 = efn.EfficientNetB0(input_shape=IMG_SHAPE, input_tensor=model_input, include_top=False, 
weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/efficientnet-b0_weights_tf_dim_ordering_tf_kernels_autoaugment_notop.h5')
for layer in base_model1.layers:
    layer.trainable = False
x1=base_model1.output
top1_model = keras.layers.GlobalAveragePooling2D()(x1)
top1_model = Dense(512, activation='relu', kernel_regularizer=regularizers.l1(0.0001))(top1_model)
top1_model = BatchNormalization()(top1_model)
top1_model = Dropout(0.5)(top1_model) 
predictions1 = keras.layers.Dense(len(classes),activation="softmax")(top1_model)
model1=Model(inputs=model_input, outputs=predictions1)
model1.compile(loss='categorical_crossentropy', optimizer=optimizer, metrics=['accuracy'])

base_model2 = keras.applications.mobilenet.MobileNet(input_shape=IMG_SHAPE, input_tensor=model_input, include_top=False, 
weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/mobilenet_1_0_224_tf_no_top.h5')
#base_model2 = keras.applications.nasnet.NASNetMobile(input_shape=IMG_SHAPE, input_tensor=model_input,include_top=False,
#weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/NASNet-mobile-no-top.h5')

for layer in base_model2.layers:
    layer.name = layer.name + str("_2")
    layer.trainable = False
x2=base_model2.output
top2_model=keras.layers.GlobalAveragePooling2D()(x2)
top2_model = Dense(512, activation='relu', kernel_regularizer=regularizers.l1(0.0001))(top2_model)
top2_model = BatchNormalization()(top2_model)
top2_model = Dropout(0.5)(top2_model) 
predictions2 = keras.layers.Dense(len(classes),activation="softmax")(top2_model)
model2=Model(inputs=model_input, outputs=predictions2)
model2.compile(loss='categorical_crossentropy', optimizer=optimizer, metrics=['accuracy'])


#base_model3 = keras.applications.xception.Xception(input_shape=IMG_SHAPE, input_tensor=model_input,include_top=False,
#weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/xception_weights_tf_dim_ordering_tf_kernels_notop.h5')
base_model3 =  keras.applications.MobileNetV2(input_shape=IMG_SHAPE, input_tensor=model_input, include_top=False, weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/mobilenet_v2_weights_tf_dim_ordering_tf_kernels_1.0_224_no_top.h5')
for layer in base_model3.layers:
    layer.trainable = False
x3=base_model3.output
top3_model=keras.layers.GlobalAveragePooling2D()(x3)
top3_model = Dense(512, activation='relu', kernel_regularizer=regularizers.l1(0.0001))(top3_model)
top3_model = BatchNormalization()(top3_model)
top3_model = Dropout(0.5)(top3_model) 
predictions3 = keras.layers.Dense(len(classes),activation="softmax")(top3_model)
model3=Model(inputs=model_input, outputs=predictions3)
model3.compile(optimizer=optimizer, loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop

def ensemble(models, model_input):
    outputs = [model.outputs[0] for model in models]
    y = layers.Average()(outputs)
    model = Model(model_input, y, name='ensemble')
    return model

model = ensemble([model1, model2, model3], model_input)
model.compile(loss='categorical_crossentropy', optimizer=optimizer, metrics=['accuracy'])


'''
#--------Xception transfer learning----------------------------------------------------------
from keras.applications.xception import Xception
from keras.layers import Dense, GlobalAveragePooling2D
from keras.models import Model
import tensorflow as tf

base_model = Xception(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/xception_weights_tf_dim_ordering_tf_kernels_notop.h5', include_top=False)
 
for layer in base_model.layers:
    layer.trainable = False
    
x = base_model.output

x = GlobalAveragePooling2D()(x) 
predictions = Dense(len(classes), activation='softmax')(x)
model = Model(inputs=base_model.input, outputs=predictions)
model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
'''


'''
#--------MobileNet V2 + SAE transfer learning----------------------------------------------------------
#--coding:utf-8--
from keras.applications.densenet import DenseNet121,preprocess_input
from keras.layers import Dense, GlobalAveragePooling2D
from keras.models import Model
from keras import applications, regularizers

IMG_SHAPE=(224, 224, 3)
model_input = Input(shape=(224,224,3))

base_model =  keras.applications.MobileNetV2(input_shape=IMG_SHAPE, input_tensor=model_input, include_top=False, weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/mobilenet_v2_weights_tf_dim_ordering_tf_kernels_1.0_224_no_top.h5')

for layer in base_model.layers:
    layer.trainable = False
    
base_out = base_model.output

encoded = Dense(128, activation='relu',activity_regularizer=regularizers.l1(10e-5))(base_out)
encoded = Dense(64, activation='relu',activity_regularizer=regularizers.l1(10e-5))(encoded)
encoded = Dense(32, activation='relu',activity_regularizer=regularizers.l1(10e-5))(encoded)
decoded = Dense(64, activation='relu')(encoded)
decoded = Dense(128, activation='relu')(decoded)
decoded = Dense(784, activation='sigmoid')(decoded)


x = GlobalAveragePooling2D()(decoded) 

#encoding_dim = 32
#x = Dense(encoding_dim, activation='relu',
#                activity_regularizer=regularizers.l1(10e-5))(x)
#x=Dense(784, activation='sigmoid')(x)

predictions = Dense(len(classes), activation='softmax')(x)
model = Model(inputs=base_model.input, outputs=predictions)

model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
'''


'''
#-------Inception_resnet_v2 transfer learning---------------
from keras.applications.inception_resnet_v2 import InceptionResNetV2,preprocess_input
from keras.layers import Dense, GlobalAveragePooling2D
from keras.models import Model
import tensorflow as tf

base_model = InceptionResNetV2(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/inception_resnet_v2_weights_tf_dim_ordering_tf_kernels_notop.h5', include_top=False)
 
for layer in base_model.layers:
    layer.trainable = False
    
x = base_model.output

x = GlobalAveragePooling2D()(x) 
predictions = Dense(len(classes), activation='softmax')(x)
model = Model(inputs=base_model.input, outputs=predictions)

model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
'''

'''
#--------VGG19 transfer learning-----------------
#coding=utf-8  
from keras.applications.vgg19 import VGG19
from keras.layers import Dense,Flatten,GlobalAveragePooling2D
from keras.layers import Input,Dense,Dropout,BatchNormalization,Conv2D,MaxPooling2D,AveragePooling2D,concatenate  
from keras.optimizers import SGD
from keras.models import Model  
from keras.preprocessing.image import ImageDataGenerator
import matplotlib.pyplot as plt
from keras.models import Sequential  
from keras.layers import Dense,Flatten,Dropout  
from keras.layers.convolutional import Conv2D,MaxPooling2D  
import numpy as np  

base_model = VGG19(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/vgg19_weights_tf_dim_ordering_tf_kernels_notop.h5', include_top=False)

for layer in base_model.layers:
    layer.trainable = False

x = base_model.output

x = GlobalAveragePooling2D()(x)

predictions = Dense(len(classes), activation='softmax')(x)

model = Model(inputs=base_model.input, outputs=predictions)

model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
'''

'''
#-------InCV3 transfer learning---------------
from keras.applications.inception_v3 import InceptionV3
from keras.preprocessing import image
from keras.models import Model
from keras.layers import Dense, GlobalAveragePooling2D
from keras import backend as K


base_model = InceptionV3(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/inception_v3_weights_tf_dim_ordering_tf_kernels_notop.h5', include_top=False)


for layer in base_model.layers:
    layer.trainable = False


x = base_model.output
x = GlobalAveragePooling2D()(x)

predictions = Dense(len(classes), activation='softmax')(x)

model = Model(inputs=base_model.input, outputs=predictions)

model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
'''

'''
#coding=utf-8  Resnet-50 transfer learning----------------
from keras.utils import plot_model
from keras.applications.resnet50 import ResNet50
from keras.models import Model  
from keras.layers import Input,Dense,BatchNormalization,Conv2D,MaxPooling2D,AveragePooling2D,ZeroPadding2D, GlobalAveragePooling2D   
from keras.layers import add,Flatten  
#from keras.layers.convolutional import Conv2D,MaxPooling2D,AveragePooling2D
from keras.optimizers import SGD  

def Conv2d_BN(x, nb_filter,kernel_size, strides=(1,1), padding='same',name=None):  
    if name is not None:  
        bn_name = name + '_bn'  
        conv_name = name + '_conv'  
    else:  
        bn_name = None  
        conv_name = None  
  
    x = Conv2D(nb_filter,kernel_size,padding=padding,strides=strides,activation='relu',name=conv_name)(x)  
    x = BatchNormalization(axis=3,name=bn_name)(x)  
    return x  

def Conv_Block(inpt,nb_filter,kernel_size,strides=(1,1), with_conv_shortcut=False):  
    x = Conv2d_BN(inpt,nb_filter=nb_filter[0],kernel_size=(1,1),strides=strides,padding='same')  
    x = Conv2d_BN(x, nb_filter=nb_filter[1], kernel_size=(3,3), padding='same')  
    x = Conv2d_BN(x, nb_filter=nb_filter[2], kernel_size=(1,1), padding='same')  
    if with_conv_shortcut:  
        shortcut = Conv2d_BN(inpt,nb_filter=nb_filter[2],strides=strides,kernel_size=kernel_size)  
        x = add([x,shortcut])  
        return x  
    else:  
        x = add([x,inpt])  
        return x  
    
K.set_learning_phase(0)
Inp = Input((224, 224, 3))
base_model = ResNet50(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/resnet50_weights_tf_dim_ordering_tf_kernels_notop.h5', 
                      include_top=False,input_shape=(224, 224, 3))

for layer in base_model.layers:
    layer.trainable = False

#----------------------------# 
x = base_model.output
x = GlobalAveragePooling2D()(x)

predictions = Dense(len(classes), activation='softmax')(x)

model = Model(inputs=base_model.input, outputs=predictions)

model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
'''

'''
#--------Densenet121 transfer learning----------------------------------------------------------
#--coding:utf-8--
from keras.applications.densenet import DenseNet121,preprocess_input
from keras.layers import Dense, GlobalAveragePooling2D
from keras.models import Model
 
base_model = DenseNet121(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/densenet121_weights_tf_dim_ordering_tf_kernels_notop.h5', include_top=False)
#base_model = DenseNet201(include_top=False)
 
for layer in base_model.layers:
    layer.trainable = False
    
x = base_model.output

x = GlobalAveragePooling2D()(x) 
predictions = Dense(len(classes), activation='softmax')(x)
model = Model(inputs=base_model.input, outputs=predictions)

model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
'''


'''
#--------Densenet+InceptionModule_transfer learning----------------------------------------------------------
from keras.applications.densenet import DenseNet121,preprocess_input
from keras.layers import Dense, GlobalAveragePooling2D
from keras.models import Model
#from keras.layers import Input,Add,Dense,Dropout,BatchNormalization,Conv2D,MaxPooling2D,AveragePooling2D,concatenate
from keras.layers import *        

def Conv2d_BN(x, nb_filter,kernel_size, padding='same',strides=(1,1),name=None):  
    if name is not None:  
        bn_name = name + '_bn'  
        conv_name = name + '_conv'  
    else:  
        bn_name = None  
        conv_name = None   
    x = Conv2D(nb_filter,kernel_size,padding=padding,strides=strides,activation='relu',name=conv_name)(x)  
#    x = Conv2D(nb_filter,kernel_size,padding=padding,strides=strides,name=conv_name)(x)
#    x = Lambda(swish)(x)
    x = BatchNormalization(axis=3,name=bn_name)(x)  
    return x  


def Inception(x,nb_filter):  
    branch1x1 = Conv2d_BN(x,nb_filter,(1,1), padding='same',strides=(1,1),name=None)  
  
    branch3x3 = Conv2d_BN(x,nb_filter,(1,1), padding='same',strides=(1,1),name=None)  
    branch3x3 = Conv2d_BN(branch3x3,nb_filter,(3,3), padding='same',strides=(1,1),name=None)  
  
    branch5x5 = Conv2d_BN(x,nb_filter,(1,1), padding='same',strides=(1,1),name=None)  
#    branch5x5 = Conv2d_BN(branch5x5,nb_filter,(1,1), padding='same',strides=(1,1),name=None)
    branch5x5 = Conv2d_BN(branch5x5,nb_filter,(3,3), padding='same',strides=(1,1),name=None)
    branch5x5 = Conv2d_BN(branch5x5,nb_filter,(3,3), padding='same',strides=(1,1),name=None)
  
    branchpool = MaxPooling2D(pool_size=(3,3),strides=(1,1),padding='same')(x)  
    branchpool = Conv2d_BN(branchpool,nb_filter,(1,1),padding='same',strides=(1,1),name=None)  
  
    x = concatenate([branch1x1,branch3x3,branch5x5,branchpool],axis=3)    
    return x  

base_model = DenseNet121(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/densenet121_weights_tf_dim_ordering_tf_kernels_notop.h5', include_top=False)
#base_model = DenseNet201(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/densenet201_weights_tf_dim_ordering_tf_kernels_notop.h5', include_top=False, input_shape=(224, 224, 3))
#base_model = DenseNet201(include_top=False, input_shape=(224, 224, 3))
 
for layer in base_model.layers:
    layer.trainable = False
x = base_model.output

x = Inception(x,256)  


x = GlobalAveragePooling2D()(x) 
#x = AveragePooling2D(pool_size=(2,2),strides=(1,1),padding='same')(x)  
#x = Flatten()(x) 
x = Dense(1024,activation='relu')(x)  
predictions = Dense(len(classes), activation='softmax')(x)
model = Model(inputs=base_model.input, outputs=predictions)

model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
'''

'''
#-------VGG19+SVM transfer learning---------------
from keras.applications.vgg19 import VGG19
from keras.preprocessing import image
from keras.models import Model
from keras.layers import Dense, GlobalAveragePooling2D
from keras import backend as K
from keras import regularizers

def categorical_squared_hinge(y_true, y_pred):
    """
    hinge with 0.5*W^2 ,SVM
    """
    y_true = 2. * y_true - 1 # trans [0,1] to [-1,1]，
    vvvv = K.maximum(1. - y_true * y_pred, 0.) # hinge loss，
#    vvv = K.square(vvvv) # 《Deep Learning using Linear Support Vector Machines》
    vv = K.sum(vvvv, 1, keepdims=False)  #axis=len(y_true.get_shape()) - 1
    v = K.mean(vv, axis=-1)
    return v


base_model = VGG19(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/vgg19_weights_tf_dim_ordering_tf_kernels_notop.h5', include_top=False)


for layer in base_model.layers:
    layer.trainable = False

x = base_model.output
x = GlobalAveragePooling2D()(x)


#predictions = Dense(len(ont_hot_labels[0]), activation='softmax')(x)
predictions = Dense(len(classes), activation='linear', #
                           kernel_regularizer=regularizers.l2(0.5),
                           name='FC_linear')(x)

model = Model(inputs=base_model.input, outputs=predictions)

model.compile(optimizer=optimizers.SGD(lr=0.0001), loss=[categorical_squared_hinge],  metrics = ['accuracy'])  #'categorical_crossentropy'   optimizers.SGD(lr=0.0001)
'''


train_datagen = ImageDataGenerator(validation_split=0.2)
train_datagen.mean = np.array([103.939, 116.779, 123.68], dtype=np.float32).reshape((3, 1, 1))  # 去掉imagenet BGR均值
train_data = train_datagen.flow_from_directory(train_dir, target_size=img_size, classes=classes)
validation_datagen = ImageDataGenerator()
validation_datagen.mean = np.array([103.939, 116.779, 123.68], dtype=np.float32).reshape((3, 1, 1))
validation_data = validation_datagen.flow_from_directory(validation_dir, target_size=img_size, classes=classes)

#---------------first stage---------------------------------------------
#model_checkpoint1 = ModelCheckpoint(filepath=MODEL_INIT, save_best_only=True, monitor='val_accuracy', mode='max')
model_checkpoint1 = ModelCheckpoint(filepath=MODEL_INIT, monitor='val_accuracy')
board1 = TensorBoard(log_dir=board_name1,
                     histogram_freq=0,
                     write_graph=True,
                     write_images=True)
callback_list1 = [model_checkpoint1, board1]

model.fit_generator(train_data, steps_per_epoch=nb_train_samples / float(batch_size),
                           epochs = epochs,
                           validation_steps=nb_validation_samples / float(batch_size),
                           validation_data=validation_data,
                           callbacks=callback_list1, verbose=2)

#---------------second stage---------------------------------------------
model_checkpoint2 = ModelCheckpoint(filepath=MODEL_PATH,  monitor='val_accuracy')
board2 = TensorBoard(log_dir=board_name2,
                     histogram_freq=0,
                     write_graph=True,
                     write_images=True)
callback_list2 = [model_checkpoint2, board2]

model.load_weights(MODEL_INIT)
for model1 in model.layers:
    model1.trainable = True
#fine_tune_at = 50
#for layer in model.layers[:fine_tune_at]:
#    layer.trainable = False


model.compile(optimizer=optimizers.SGD(lr=0.0001), loss = [focal_loss(gamma=2)], metrics=['accuracy']) #loss='categorical_crossentropy'
#model.compile(optimizer=optimizers.Adadelta(), loss = [focal_loss(gamma=2)], metrics=['accuracy']) #loss='categorical_crossentropy',

model.fit_generator(train_data, steps_per_epoch=nb_train_samples / float(batch_size), epochs=epochs,
                    validation_data=validation_data, validation_steps=nb_validation_samples / float(batch_size),
                    callbacks=callback_list2, verbose=2)







